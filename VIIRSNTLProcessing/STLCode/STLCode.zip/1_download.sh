#!/bin/bash

#SBATCH --job-name=VIIRS.Download
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --partition=pi_seto
#SBATCH --time=4-23
#SBATCH --mem-per-cpu=4G

mkdir /home/pb438/scratch60/VIIRS_Global_TSA
wget https://eogdata.mines.edu/wwwdata/viirs_products/dnb_composites/v10/ -r --no-parent -P /home/pb438/scratch60/VIIRS_Global_TSA -A .tgz --tries=inf --no-check-certificate
