#!/bin/bash

#SBATCH --job-name=VIIRSUnzip
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --partition=pi_seto
#SBATCH --time=23:30:00
#SBATCH --mem-per-cpu=8192mb


cd /home/pb438/scratch60/VIIRS_Global_TSA/eogdata.mines.edu/wwwdata/viirs_products/dnb_composites/v10
mkdir -p /home/pb438/scratch60/VIIRS_Global

for x in `find "$PWD" -type f -name "*.tgz"`; do
tar zxvf $x -C /home/pb438/scratch60/VIIRS_Global;
done

echo "Done"
