# This Script generates list of files by tiles for average radiance (vcmcfg; product with stray light excluded)
# This Script needs all images in /gpfs/loomis/scratch60/pb438/VIIRS_Global/
# The Script also needs the folder to save the image lists to "/gpfs/loomis/scratch60/pb438/Junk"
# Finally the script uses dir.exists in R versions > 3.2.0. Load module load Apps/R/3.3.2-generic
# The script will return an error if the images do not exit or if the Junk Folder does not exist


rm(list=ls())
setwd("/home/pb438/scratch60/VIIRS_Global")

pathtojunk = "/home/pb438/scratch60/Junk"

files = list.files(pattern="*.tif")

if(length(files) > 0 & dir.exists(pathtojunk)){
  ## All Files
  vcmcfg = c()
  for(i in 1:length(files)){
    fname = as.character(files[i])
    if(grepl("vcmcfg",fname)){
      vcmcfg = append(vcmcfg,fname)
    }
  }
  
  ## Only average radiance file
  avg_rade9h.files = c()
  
  for(i in 1:length(vcmcfg)){
    fname = vcmcfg[i]
    if(grepl("avg_rade9h.tif",fname)){
      avg_rade9h.files = append(avg_rade9h.files,fname)
    }
  }
  
  ## Only cloud free coverage files
  cf_cvg.files = c()
  
  for(i in 1:length(vcmcfg)){
    fname = vcmcfg[i]
    if(grepl("cf_cvg.tif",fname)){
      cf_cvg.files = append(cf_cvg.files,fname)
    }
  }
  
  tilenames = unique(as.character(lapply(avg_rade9h.files,function(x)strsplit(x,"_")[[1]][4])))
  print(tilenames)
  ## Average Radiance VCM Cloud Free Coverage
  
  avgrad_00N060E = c()
  
  for(i in 1:length(avg_rade9h.files)){
    fname = avg_rade9h.files[i]
    if(grepl("00N060E",fname)){
      avgrad_00N060E = append(avgrad_00N060E,fname)
    }
  }
  
  avgrad_00N060W = c()
  
  for(i in 1:length(avg_rade9h.files)){
    fname = avg_rade9h.files[i]
    if(grepl("00N060W",fname)){
      avgrad_00N060W = append(avgrad_00N060W,fname)
    }
  }
  
  avgrad_00N180W = c()
  
  for(i in 1:length(avg_rade9h.files)){
    fname = avg_rade9h.files[i]
    if(grepl("00N180W",fname)){
      avgrad_00N180W = append(avgrad_00N180W,fname)
    }
  }
  
  
  avgrad_75N060E = c()
  
  for(i in 1:length(avg_rade9h.files)){
    fname = avg_rade9h.files[i]
    if(grepl("75N060E",fname)){
      avgrad_75N060E = append(avgrad_75N060E,fname)
    }
  }
  
  avgrad_75N060W = c()
  
  for(i in 1:length(avg_rade9h.files)){
    fname = avg_rade9h.files[i]
    if(grepl("75N060W",fname)){
      avgrad_75N060W = append(avgrad_75N060W,fname)
    }
  }
  
  avgrad_75N180W = c()
  
  for(i in 1:length(avg_rade9h.files)){
    fname = avg_rade9h.files[i]
    if(grepl("75N180W",fname)){
      avgrad_75N180W = append(avgrad_75N180W,fname)
    }
  }
  
  ## VCM Cloud Free Coverage
  
  cf_cvg_00N060E = c()
  
  for(i in 1:length(cf_cvg.files)){
    fname = cf_cvg.files[i]
    if(grepl("00N060E",fname)){
      cf_cvg_00N060E = append(cf_cvg_00N060E,fname)
    }
  }
  
  cf_cvg_00N060W = c()
  
  for(i in 1:length(cf_cvg.files)){
    fname = cf_cvg.files[i]
    if(grepl("00N060W",fname)){
      cf_cvg_00N060W = append(cf_cvg_00N060W,fname)
    }
  }
  
  cf_cvg_00N180W = c()
  
  for(i in 1:length(cf_cvg.files)){
    fname = cf_cvg.files[i]
    if(grepl("00N180W",fname)){
      cf_cvg_00N180W = append(cf_cvg_00N180W,fname)
    }
  }
  
  
  cf_cvg_75N060E = c()
  
  for(i in 1:length(cf_cvg.files)){
    fname = cf_cvg.files[i]
    if(grepl("75N060E",fname)){
      cf_cvg_75N060E = append(cf_cvg_75N060E,fname)
    }
  }
  
  cf_cvg_75N060W = c()
  
  for(i in 1:length(cf_cvg.files)){
    fname = cf_cvg.files[i]
    if(grepl("75N060W",fname)){
      cf_cvg_75N060W = append(cf_cvg_75N060W,fname)
    }
  }
  
  cf_cvg_75N180W = c()
  
  for(i in 1:length(cf_cvg.files)){
    fname = cf_cvg.files[i]
    if(grepl("75N180W",fname)){
      cf_cvg_75N180W = append(cf_cvg_75N180W,fname)
    }
  }
  avgrad_00N060E = paste0("/home/pb438/scratch60/VIIRS_Global/",avgrad_00N060E)
  avgrad_00N060W = paste0("/home/pb438/scratch60/VIIRS_Global/",avgrad_00N060W)
  avgrad_00N180W = paste0("/home/pb438/scratch60/VIIRS_Global/",avgrad_00N180W)
  avgrad_75N060E = paste0("/home/pb438/scratch60/VIIRS_Global/",avgrad_75N060E)
  avgrad_75N060W = paste0("/home/pb438/scratch60/VIIRS_Global/",avgrad_75N060W)
  avgrad_75N180W = paste0("/home/pb438/scratch60/VIIRS_Global/",avgrad_75N180W)
  
  cf_cvg_00N060E = paste0("/home/pb438/scratch60/VIIRS_Global/",cf_cvg_00N060E)
  cf_cvg_00N060W = paste0("/home/pb438/scratch60/VIIRS_Global/",cf_cvg_00N060W)
  cf_cvg_00N180W = paste0("/home/pb438/scratch60/VIIRS_Global/",cf_cvg_00N180W)
  cf_cvg_75N060E = paste0("/home/pb438/scratch60/VIIRS_Global/",cf_cvg_75N060E)
  cf_cvg_75N060W = paste0("/home/pb438/scratch60/VIIRS_Global/",cf_cvg_75N060W)
  cf_cvg_75N180W = paste0("/home/pb438/scratch60/VIIRS_Global/",cf_cvg_75N180W)
  
  
  
  write.table(avgrad_00N060E, "/home/pb438/scratch60/Junk/avgrad_00N060E.txt",row.names=F,col.names=F,quote=F)
  write.table(avgrad_00N060W, "/home/pb438/scratch60/Junk/avgrad_00N060W.txt",row.names=F,col.names=F,quote=F)
  write.table(avgrad_00N180W, "/home/pb438/scratch60/Junk/avgrad_00N180W.txt",row.names=F,col.names=F,quote=F)
  write.table(avgrad_75N060E, "/home/pb438/scratch60/Junk/avgrad_75N060E.txt",row.names=F,col.names=F,quote=F)
  write.table(avgrad_75N060W, "/home/pb438/scratch60/Junk/avgrad_75N060W.txt",row.names=F,col.names=F,quote=F)
  write.table(avgrad_75N180W, "/home/pb438/scratch60/Junk/avgrad_75N180W.txt",row.names=F,col.names=F,quote=F)
  
  write.table(cf_cvg_00N060E, "/home/pb438/scratch60/Junk/cf_cvg_00N060E.txt",row.names=F,col.names=F,quote=F)
  write.table(cf_cvg_00N060W, "/home/pb438/scratch60/Junk/cf_cvg_00N060W.txt",row.names=F,col.names=F,quote=F)
  write.table(cf_cvg_00N180W, "/home/pb438/scratch60/Junk/cf_cvg_00N180W.txt",row.names=F,col.names=F,quote=F)
  write.table(cf_cvg_75N060E, "/home/pb438/scratch60/Junk/cf_cvg_75N060E.txt",row.names=F,col.names=F,quote=F)
  write.table(cf_cvg_75N060W, "/home/pb438/scratch60/Junk/cf_cvg_75N060W.txt",row.names=F,col.names=F,quote=F)
  write.table(cf_cvg_75N180W, "/home/pb438/scratch60/Junk/cf_cvg_75N180W.txt",row.names=F,col.names=F,quote=F)
  
  print("All VCMcfg TextFiles Created")
  #################################################################################################################################################
  #################################################################################################################################################
  #################################################################################################################################################
  #################################################################################################################################################
  #################################################################################################################################################
  #################################################################################################################################################
  #################################################################################################################################################
  #################################################################################################################################################

  ## All Files
  vcmslcfg = c()
  for(i in 1:length(files)){
    fname = as.character(files[i])
    if(grepl("vcmslcfg",fname)){
      vcmslcfg = append(vcmslcfg,fname)
    }
  }
  
  ## Only average radiance file
  avg_rade9h.files = c()
  
  for(i in 1:length(vcmslcfg)){
    fname = vcmslcfg[i]
    if(grepl("avg_rade9h.tif",fname)){
      avg_rade9h.files = append(avg_rade9h.files,fname)
    }
  }
  
  ## Only cloud free coverage files
  cf_cvg.files = c()
  
  for(i in 1:length(vcmslcfg)){
    fname = vcmslcfg[i]
    if(grepl("cf_cvg.tif",fname)){
      cf_cvg.files = append(cf_cvg.files,fname)
    }
  }
  
  tilenames = unique(as.character(lapply(avg_rade9h.files,function(x)strsplit(x,"_")[[1]][4])))
  print(tilenames)
  ## Average Radiance VCM Cloud Free Coverage
  
  avgrad_00N060E = c()  

  for(i in 1:length(avg_rade9h.files)){
    fname = avg_rade9h.files[i]
    Condn=grepl("00N060E",fname)
    print(paste(i,Condn,fname,sep=" "))
    if(Condn){
      avgrad_00N060E = append(avgrad_00N060E,fname)
    }
  }
  
  avgrad_00N060W = c()
  
  for(i in 1:length(avg_rade9h.files)){
    fname = avg_rade9h.files[i]
    if(grepl("00N060W",fname)){
      avgrad_00N060W = append(avgrad_00N060W,fname)
    }
  }
  
  avgrad_00N180W = c()
  
  for(i in 1:length(avg_rade9h.files)){
    fname = avg_rade9h.files[i]
    if(grepl("00N180W",fname)){
      avgrad_00N180W = append(avgrad_00N180W,fname)
    }
  }
  
  
  avgrad_75N060E = c()
  
  for(i in 1:length(avg_rade9h.files)){
    fname = avg_rade9h.files[i]
    if(grepl("75N060E",fname)){
      avgrad_75N060E = append(avgrad_75N060E,fname)
    }
  }
  
  avgrad_75N060W = c()
  
  for(i in 1:length(avg_rade9h.files)){
    fname = avg_rade9h.files[i]
    if(grepl("75N060W",fname)){
      avgrad_75N060W = append(avgrad_75N060W,fname)
    }
  }
  
  avgrad_75N180W = c()
  
  for(i in 1:length(avg_rade9h.files)){
    fname = avg_rade9h.files[i]
    if(grepl("75N180W",fname)){
      avgrad_75N180W = append(avgrad_75N180W,fname)
    }
  }
  
  ## VCM Cloud Free Coverage
  
  cf_cvg_00N060E = c()
  
  for(i in 1:length(cf_cvg.files)){
    fname = cf_cvg.files[i]
    Condn=grepl("00N060E",fname)
  #  print(paste(i,Condn,fname,sep=" "))
    if(Condn){
        cf_cvg_00N060E = append(cf_cvg_00N060E,fname)
    }
  }
  
  cf_cvg_00N060W = c()
  
  for(i in 1:length(cf_cvg.files)){
    fname = cf_cvg.files[i]
    if(grepl("00N060W",fname)){
      cf_cvg_00N060W = append(cf_cvg_00N060W,fname)
    }
  }
  
  cf_cvg_00N180W = c()
  
  for(i in 1:length(cf_cvg.files)){
    fname = cf_cvg.files[i]
    if(grepl("00N180W",fname)){
      cf_cvg_00N180W = append(cf_cvg_00N180W,fname)
    }
  }
  
  
  cf_cvg_75N060E = c()
  
  for(i in 1:length(cf_cvg.files)){
    fname = cf_cvg.files[i]
    if(grepl("75N060E",fname)){
      cf_cvg_75N060E = append(cf_cvg_75N060E,fname)
    }
  }
  
  cf_cvg_75N060W = c()
  
  for(i in 1:length(cf_cvg.files)){
    fname = cf_cvg.files[i]
    if(grepl("75N060W",fname)){
      cf_cvg_75N060W = append(cf_cvg_75N060W,fname)
    }
  }
  
  cf_cvg_75N180W = c()
  
  for(i in 1:length(cf_cvg.files)){
    fname = cf_cvg.files[i]
    if(grepl("75N180W",fname)){
      cf_cvg_75N180W = append(cf_cvg_75N180W,fname)
    }
  }
  avgrad_00N060E = paste0("/home/pb438/scratch60/VIIRS_Global/",avgrad_00N060E)
  avgrad_00N060W = paste0("/home/pb438/scratch60/VIIRS_Global/",avgrad_00N060W)
  avgrad_00N180W = paste0("/home/pb438/scratch60/VIIRS_Global/",avgrad_00N180W)
  avgrad_75N060E = paste0("/home/pb438/scratch60/VIIRS_Global/",avgrad_75N060E)
  avgrad_75N060W = paste0("/home/pb438/scratch60/VIIRS_Global/",avgrad_75N060W)
  avgrad_75N180W = paste0("/home/pb438/scratch60/VIIRS_Global/",avgrad_75N180W)
  
  cf_cvg_00N060E = paste0("/home/pb438/scratch60/VIIRS_Global/",cf_cvg_00N060E)
  cf_cvg_00N060W = paste0("/home/pb438/scratch60/VIIRS_Global/",cf_cvg_00N060W)
  cf_cvg_00N180W = paste0("/home/pb438/scratch60/VIIRS_Global/",cf_cvg_00N180W)
  cf_cvg_75N060E = paste0("/home/pb438/scratch60/VIIRS_Global/",cf_cvg_75N060E)
  cf_cvg_75N060W = paste0("/home/pb438/scratch60/VIIRS_Global/",cf_cvg_75N060W)
  cf_cvg_75N180W = paste0("/home/pb438/scratch60/VIIRS_Global/",cf_cvg_75N180W)
  
  
  
  write.table(avgrad_00N060E, "/home/pb438/scratch60/Junk/avgradsl_00N060E.txt",row.names=F,col.names=F,quote=F)
  write.table(avgrad_00N060W, "/home/pb438/scratch60/Junk/avgradsl_00N060W.txt",row.names=F,col.names=F,quote=F)
  write.table(avgrad_00N180W, "/home/pb438/scratch60/Junk/avgradsl_00N180W.txt",row.names=F,col.names=F,quote=F)
  write.table(avgrad_75N060E, "/home/pb438/scratch60/Junk/avgradsl_75N060E.txt",row.names=F,col.names=F,quote=F)
  write.table(avgrad_75N060W, "/home/pb438/scratch60/Junk/avgradsl_75N060W.txt",row.names=F,col.names=F,quote=F)
  write.table(avgrad_75N180W, "/home/pb438/scratch60/Junk/avgradsl_75N180W.txt",row.names=F,col.names=F,quote=F)
  
  write.table(cf_cvg_00N060E, "/home/pb438/scratch60/Junk/cf_cvgsl_00N060E.txt",row.names=F,col.names=F,quote=F)
  write.table(cf_cvg_00N060W, "/home/pb438/scratch60/Junk/cf_cvgsl_00N060W.txt",row.names=F,col.names=F,quote=F)
  write.table(cf_cvg_00N180W, "/home/pb438/scratch60/Junk/cf_cvgsl_00N180W.txt",row.names=F,col.names=F,quote=F)
  write.table(cf_cvg_75N060E, "/home/pb438/scratch60/Junk/cf_cvgsl_75N060E.txt",row.names=F,col.names=F,quote=F)
  write.table(cf_cvg_75N060W, "/home/pb438/scratch60/Junk/cf_cvgsl_75N060W.txt",row.names=F,col.names=F,quote=F)
  write.table(cf_cvg_75N180W, "/home/pb438/scratch60/Junk/cf_cvgsl_75N180W.txt",row.names=F,col.names=F,quote=F)
  
  print("All VCMSL TextFiles Created")
  
}else{
  cat("Check Images or the Output Junk Folder")
}
