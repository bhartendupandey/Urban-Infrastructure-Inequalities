#!/bin/bash

#SBATCH --job-name=buildvrt
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --partition=pi_seto
#SBATCH --time=1:30:00
#SBATCH --mem-per-cpu=8192mb

#module load Apps/R/3.3.2-generic
#module load Libs/GDAL/2.2.4

module load R/3.5.3-foss-2018a-X11-20180131
module load GDAL/2.2.3-foss-2018a-Python-2.7.14

mkdir /home/pb438/scratch60/Junk

cd /home/pb438/project/Script/Paper\ 2/STLDecomposition
Rscript 3_Filelist.R --vanilla

echo "All Text Files Created"

cd /home/pb438/scratch60/Junk
mkdir /home/pb438/scratch60/VIIRS_Global_vrt/

gdalbuildvrt -separate -input_file_list avgrad_00N060E.txt /home/pb438/scratch60/VIIRS_Global_vrt/avgrad_00N060E.vrt
gdalbuildvrt -separate -input_file_list avgrad_00N060W.txt /home/pb438/scratch60/VIIRS_Global_vrt/avgrad_00N060W.vrt
gdalbuildvrt -separate -input_file_list avgrad_00N180W.txt /home/pb438/scratch60/VIIRS_Global_vrt/avgrad_00N180W.vrt
gdalbuildvrt -separate -input_file_list avgrad_75N060E.txt /home/pb438/scratch60/VIIRS_Global_vrt/avgrad_75N060E.vrt
gdalbuildvrt -separate -input_file_list avgrad_75N060W.txt /home/pb438/scratch60/VIIRS_Global_vrt/avgrad_75N060W.vrt
gdalbuildvrt -separate -input_file_list avgrad_75N180W.txt /home/pb438/scratch60/VIIRS_Global_vrt/avgrad_75N180W.vrt

gdalbuildvrt -separate -input_file_list cf_cvg_00N060E.txt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvg_00N060E.vrt
gdalbuildvrt -separate -input_file_list cf_cvg_00N060W.txt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvg_00N060W.vrt
gdalbuildvrt -separate -input_file_list cf_cvg_00N180W.txt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvg_00N180W.vrt
gdalbuildvrt -separate -input_file_list cf_cvg_75N060E.txt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvg_75N060E.vrt
gdalbuildvrt -separate -input_file_list cf_cvg_75N060W.txt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvg_75N060W.vrt
gdalbuildvrt -separate -input_file_list cf_cvg_75N180W.txt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvg_75N180W.vrt

gdalbuildvrt -separate -input_file_list avgradsl_00N060E.txt /home/pb438/scratch60/VIIRS_Global_vrt/avgradsl_00N060E.vrt
gdalbuildvrt -separate -input_file_list avgradsl_00N060W.txt /home/pb438/scratch60/VIIRS_Global_vrt/avgradsl_00N060W.vrt
gdalbuildvrt -separate -input_file_list avgradsl_00N180W.txt /home/pb438/scratch60/VIIRS_Global_vrt/avgradsl_00N180W.vrt
gdalbuildvrt -separate -input_file_list avgradsl_75N060E.txt /home/pb438/scratch60/VIIRS_Global_vrt/avgradsl_75N060E.vrt
gdalbuildvrt -separate -input_file_list avgradsl_75N060W.txt /home/pb438/scratch60/VIIRS_Global_vrt/avgradsl_75N060W.vrt
gdalbuildvrt -separate -input_file_list avgradsl_75N180W.txt /home/pb438/scratch60/VIIRS_Global_vrt/avgradsl_75N180W.vrt

gdalbuildvrt -separate -input_file_list cf_cvgsl_00N060E.txt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvgsl_00N060E.vrt
gdalbuildvrt -separate -input_file_list cf_cvgsl_00N060W.txt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvgsl_00N060W.vrt
gdalbuildvrt -separate -input_file_list cf_cvgsl_00N180W.txt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvgsl_00N180W.vrt
gdalbuildvrt -separate -input_file_list cf_cvgsl_75N060E.txt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvgsl_75N060E.vrt
gdalbuildvrt -separate -input_file_list cf_cvgsl_75N060W.txt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvgsl_75N060W.vrt
gdalbuildvrt -separate -input_file_list cf_cvgsl_75N180W.txt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvgsl_75N180W.vrt

cd /home/pb438/scratch60/VIIRS_Global_vrt

gdalbuildvrt /home/pb438/scratch60/VIIRS_Global_vrt/avgrad.vrt /home/pb438/scratch60/VIIRS_Global_vrt/avgrad_00N060E.vrt /home/pb438/scratch60/VIIRS_Global_vrt/avgrad_00N060W.vrt /home/pb438/scratch60/VIIRS_Global_vrt/avgrad_00N180W.vrt /home/pb438/scratch60/VIIRS_Global_vrt/avgrad_75N060E.vrt /home/pb438/scratch60/VIIRS_Global_vrt/avgrad_75N060W.vrt /home/pb438/scratch60/VIIRS_Global_vrt/avgrad_75N180W.vrt -overwrite

gdalbuildvrt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvg.vrt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvg_00N060E.vrt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvg_00N060W.vrt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvg_00N180W.vrt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvg_75N060E.vrt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvg_75N060W.vrt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvg_75N180W.vrt -overwrite


gdalbuildvrt /home/pb438/scratch60/VIIRS_Global_vrt/avgradsl.vrt /home/pb438/scratch60/VIIRS_Global_vrt/avgradsl_00N060E.vrt /home/pb438/scratch60/VIIRS_Global_vrt/avgradsl_00N060W.vrt /home/pb438/scratch60/VIIRS_Global_vrt/avgradsl_00N180W.vrt /home/pb438/scratch60/VIIRS_Global_vrt/avgradsl_75N060E.vrt /home/pb438/scratch60/VIIRS_Global_vrt/avgradsl_75N060W.vrt /home/pb438/scratch60/VIIRS_Global_vrt/avgradsl_75N180W.vrt -overwrite

gdalbuildvrt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvgsl.vrt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvgsl_00N060E.vrt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvgsl_00N060W.vrt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvgsl_00N180W.vrt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvgsl_75N060E.vrt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvgsl_75N060W.vrt /home/pb438/scratch60/VIIRS_Global_vrt/cf_cvgsl_75N180W.vrt -overwrite

rm /home/pb438/scratch60/Junk/*.*
rmdir /home/pb438/scratch60/Junk
echo "All VRT's Created"
