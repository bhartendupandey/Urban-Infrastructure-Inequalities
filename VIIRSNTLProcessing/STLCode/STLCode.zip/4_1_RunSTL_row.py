import sys
import glob
import os
import numpy as np
from tsapython import *
import pandas as pd
from statsmodels.tsa.seasonal import STL

folder = "/home/fas/seto/pb438/scratch60/VIIRS_Global_vrt"
lineno = int(sys.argv[1])
rows = 33600
cols = 86400

outfilepath = "/home/pb438/scratch60/Output/NPYs"
lmask = "/home/pb438/project/Script/Paper 2/STLDecomposition/Landmask/Landmask.tif"
avgradfile = folder + '/' + 'avgrad.vrt'
avgradslfile = folder + '/' + 'avgradsl.vrt'
cf_cvgfile = folder + '/' + 'cf_cvg.vrt'
cf_cvgslfile = folder + '/' + 'cf_cvgsl.vrt'

outputmat = np.zeros((8,cols), dtype=float)

def getpandasfull(mat1,mat2,colno,date1,date2):
	ts1 = mat1[:,colno]
	ts2 = mat2[:,colno]
	months = np.asarray(pd.date_range(date1,date2,freq='MS').strftime("%m").tolist(),dtype='int').flatten()
	years = np.asarray(pd.date_range(date1,date2,freq='MS').strftime("%Y").tolist(),dtype='int').flatten()
	pd1 = pd.DataFrame(data={'Year':years,'Month':months,"avgrad":ts1})
	pd2 = pd.DataFrame(data={'Year':years,'Month':months,"cf_cvg":ts2})
	mer = pd1.merge(pd2,on=["Month","Year"],how="outer")
	mer.loc[mer['avgrad'] <=0, 'avgrad'] = 0
	return(mer)


outfile = outfilepath + '/' + str(lineno) + '.out'
if not os.path.exists(outfile):
	mat1 = openvrt(avgradfile,lineno)
	mat2 = openvrt(avgradslfile,lineno)
	mat3 = openvrt(cf_cvgfile,lineno)
	mat4 = openvrt(cf_cvgslfile,lineno)
	date1 = "2012-4-1"
	date2 = "2019-12-1"
	date11 = "2014-1-1"
	landmask = readraster(lmask,lineno)
	landmask = landmask.flatten()
	for i in range(cols):
		if landmask[i] == 1:
			initmer=getpandasfull(mat1,mat3,i,date1,date2)	
			initmer1=getpandasfull(mat2,mat4,i,date11,date2)			
			fulldata = initmer.merge(initmer1,on=["Month","Year"],how="outer")
			fulldata.columns=["Year","Month","avgrad","cf_cvg","avgradsl","cf_cvgsl"]
			initmer = outlierremoval(initmer)				
			fulldata.loc[(fulldata['avgrad'] == 0) & (~fulldata['avgradsl'].isnull()), 'cf_cvg'] = fulldata.loc[(fulldata['avgrad'] == 0) & (~fulldata['avgradsl'].isnull()), 'cf_cvgsl']
			fulldata.loc[(fulldata['avgrad'] == 0) & (~fulldata['avgradsl'].isnull()), 'avgrad'] = fulldata.loc[(fulldata['avgrad'] == 0) & (~fulldata['avgradsl'].isnull()), 'avgradsl']
			fulldata["avgrad"].fillna(0,inplace=True)
			stlout = STL(fulldata["avgrad"],period=12,robust=True)
			res = stlout.fit()
			trend= res.trend
			fulldata["Trend"]=trend
			out = fulldata.groupby('Year')['Trend'].mean()
			outputmat[:,i] = out.values
		else:
			outputmat[:,i] = np.repeat(0,8).astype('float')
	np.savez(outfile, outputmat)
	print(lineno)
else:
	print(lineno)
	print("File Exists")
