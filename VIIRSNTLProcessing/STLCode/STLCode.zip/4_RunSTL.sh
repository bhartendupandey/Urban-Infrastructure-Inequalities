#!/bin/bash

#SBATCH --job-name=VIIRS_RunSTL
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --partition=pi_seto
#SBATCH --time=3-00:00:00
#SBATCH --mem-per-cpu=8000mb

module load miniconda
source activate gis

jj=${SLURM_ARRAY_TASK_ID}

cd /home/pb438/project/Script/Paper\ 2/STLDecomposition

python 4_1_RunSTL_block.py $jj

conda deactivate
