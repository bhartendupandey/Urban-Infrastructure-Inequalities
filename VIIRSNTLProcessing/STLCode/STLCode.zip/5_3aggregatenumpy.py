import sys
import glob
import os
import numpy as np
import rasterio
from osgeo import gdal_array,gdal, gdalnumeric, ogr, osr,gdalconst
import pandas as pd

filen = "/home/pb438/scratch60/VIIRS_Global_vrt/avgrad.vrt"

i = int(sys.argv[1])

src= gdal.Open(filen)
rows=src.RasterYSize
cols = src.RasterXSize
trans = src.GetGeoTransform()
proj = src.GetProjection()

folder = "/home/pb438/project/Scratch60/Output/Images/"
outfile = os.path.join(folder,"Tmustl_" + str(i) + '.tif')
outdriver = gdal.GetDriverByName("GTiff")
outdata1 = outdriver.Create(outfile, cols, rows, 1, gdal.GDT_Float32)
outdata1.SetGeoTransform(trans)
outdata1.SetProjection(proj)
outdata1 = None
outdriver = None

for j in range(rows):
	npfol = "/home/pb438/project/Scratch60/Output/NPYs"
	npfil = npfol + "/" + str(j+1) + ".out.npz"
	f = np.load(npfil)
	f = f['arr_0']
	outmat = f[i-1,].astype("float32").reshape((1,86400))
	outdata1 = gdal.Open(outfile, gdalconst.GA_Update)
	outdata1.GetRasterBand(1).WriteArray(outmat,0,j)
	outdata1.FlushCache()

data = None
outdata1 = None
