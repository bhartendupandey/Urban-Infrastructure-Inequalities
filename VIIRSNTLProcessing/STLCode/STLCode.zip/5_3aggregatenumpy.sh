#!/bin/bash

#SBATCH --job-name=VIIRSNPY2IM
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --partition=pi_seto
#SBATCH --time=23:00:00
#SBATCH --mem-per-cpu=12000mb

module load miniconda
source activate gis
mkdir -p /home/pb438/scratch60/Output/Images
cd /home/pb438/project/Script/Paper\ 2/STLDecomposition
jj=${SLURM_ARRAY_TASK_ID}
python 5_3aggregatenumpy.py $jj

conda deactivate
