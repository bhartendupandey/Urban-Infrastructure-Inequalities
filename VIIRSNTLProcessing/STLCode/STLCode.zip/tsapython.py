import os
import pandas as pd
import glob
import numpy as np
from scipy.optimize import curve_fit
import rasterio
import gdal
import affine


## Getallvrts searches through the input folder to report VRTs for the specified tile.

def getallvrts(folder,tilename):
	allvrts = [y for x in os.walk(folder) for y in glob.glob(os.path.join(x[0], '*.vrt'))]
	files  = [s for s in allvrts if tilename in s]
	return(files)

def getimtypefromvrts(files):
	imname = list()
	for i in files:
		imname.append("".join(i.split('/')[-1].split(".")[-2].split("_")[-2:-1]))
	return(imname)



## OPENVRT will read the specified line from the given vrt filename 

def openvrt(filename,lineno):
	with rasterio.open(filename) as src:
		rows=src.height
		cols=src.width
		bands=src.count
		m1 = np.zeros((bands,cols), dtype=float)
		for i in range(1,bands+1):
			m1[i-1,] = src.read(i, window=((lineno-1,lineno), (0, cols)))
	return(m1)

def get_tif_filenamefrom_vrt(filename):
	src= gdal.Open(filename)
	flist=src.GetFileList()
	src=None
	return(flist[1:])

def filenametomonth(flist):
	year = list()
	month = list()
	for i in flist:
		date=i.split("_")[3].split('-')
		year1=date[0][0:4]
		month1=date[0][4:6]
		year.append(year1)
		month.append(month1)
	return(year,month)



def test_func(x, a, a1, a2, m,m1):
	return a + (a1 * np.sin(2 * np.pi * x / 12)) + (a2 * np.cos(2 * np.pi * x / 12)) + m * x * x + m1 * x


def tsa_algorithm(mat1,mat2,mat3,mat4,colno,years,months,imname):
	ts1 = mat1[:,colno]
	ts2 = mat2[:,colno]
	ts3 = mat3[:,colno]
	ts4 = mat4[:,colno]
	pd1 = pd.DataFrame(data={'Year':years[0],'Month':months[0],imname[0]:ts1})
	pd2 = pd.DataFrame(data={'Year':years[1],'Month':months[1],imname[1]:ts2})
	pd3 = pd.DataFrame(data={'Year':years[2],'Month':months[2],imname[2]:ts3})
	pd4 = pd.DataFrame(data={'Year':years[3],'Month':months[3],imname[3]:ts4})
	mer = pd1.merge(pd2,on=["Month","Year"],how="outer")
	mer = mer.merge(pd3,on=["Month","Year"],how="outer")
	mer = mer.merge(pd4,on=["Month","Year"],how="outer")
	mer.fillna(0,inplace=True)
	# Set negative values to zero
	mer.loc[mer['avgrad'] <=0, 'avgrad'] = 0
	mer.loc[mer['avgradsl'] <=0, 'avgradsl'] = 0
	# Replace zero values in avgrad with avgradsl
	mer.loc[mer['avgrad'] == 0, 'avgrad'] = mer.loc[mer['avgrad'] == 0, 'avgradsl']
	# Set Remaining zero values in avgrad as nan
	mer.loc[mer['avgrad'] ==0,'avgrad'] = np.nan
	check=np.sum(mer.avgrad.isnull().values) > 65 # GREATER THAN 75% pixels should have a value
	if check:
		out = np.repeat(0,9)
	else:
		# Interpolate Nan Values	
		#mer.avgrad.interpolate(method="spline",order=2,inplace=True)
		#mer.avgrad.interpolate(method="linear",inplace=True)
		mer.avgrad.interpolate(method="akima",inplace=True)
		# Set Remaining Nan Values as zero
		mer.avgrad= mer.avgrad.fillna(0)
		#Fit Curve
		y = mer.avgrad.values
		x = np.arange(1,87,1).astype("float")
		popt, pcov = curve_fit(test_func, x, y, method='lm')
		yhat = test_func(x, *popt)
		xx = np.arange(-2,86+8)
		yy = popt[0] + (popt[1]*np.sin(2*np.pi*xx/12)) + (popt[2]*np.cos(2*np.pi*xx/12)) + (popt[3] * xx * xx) + (popt[4] * xx)
		mer['yhat'] = yhat
		#out = mer.groupby('Year')['yhat'].mean()
		fullyears= np.repeat(range(2012,2020),12)
		outpd= pd.DataFrame(data={'Year':fullyears,'Yhat':yy})
		out = outpd.groupby('Year')['Yhat'].mean()
		tss = sum((mer.avgrad - mer.avgrad.mean()).pow(2))
		rss = sum((mer.avgrad - mer.yhat).pow(2))
		r2 = 1 - (rss/tss)
		out = np.append(out,r2)
	return(out,mer)

def getpandas(mat1,mat2,mat3,mat4,colno,years,months,imname):
	ts1 = mat1[:,colno]
	ts2 = mat2[:,colno]
	ts3 = mat3[:,colno]
	ts4 = mat4[:,colno]
	pd1 = pd.DataFrame(data={'Year':years[0],'Month':months[0],imname[0]:ts1})
	pd2 = pd.DataFrame(data={'Year':years[1],'Month':months[1],imname[1]:ts2})
	pd3 = pd.DataFrame(data={'Year':years[2],'Month':months[2],imname[2]:ts3})
	pd4 = pd.DataFrame(data={'Year':years[3],'Month':months[3],imname[3]:ts4})
	mer = pd1.merge(pd2,on=["Month","Year"],how="outer")
	mer = mer.merge(pd3,on=["Month","Year"],how="outer")
	mer = mer.merge(pd4,on=["Month","Year"],how="outer")
	mer.fillna(0,inplace=True)
	# Set negative values to zero
	mer.loc[mer['avgrad'] <=0, 'avgrad'] = 0
	mer.loc[mer['avgradsl'] <=0, 'avgradsl'] = 0
	return(mer)

# Ray-casting Method for point in polygon.
def point_in_poly(x,y,poly):
    n = len(poly)
    inside = False
    p1x,p1y = poly[0]
    for i in range(n+1):
        p2x,p2y = poly[i % n]
        if y > min(p1y,p2y):
            if y <= max(p1y,p2y):
                if x <= max(p1x,p2x):
                    if p1y != p2y:
                        xints = (y-p1y)*(p2x-p1x)/(p2y-p1y)+p1x
                    if p1x == p2x or x <= xints:
                        inside = not inside
        p1x,p1y = p2x,p2y
    return inside

# Pixel_Value from corrdinates
def retrieve_pixel_value(geo_coord, data_source):
    """Return floating-point value that corresponds to given point."""
    x, y = geo_coord[0], geo_coord[1]
    forward_transform =  \
        affine.Affine.from_gdal(*data_source.GetGeoTransform())
    reverse_transform = ~forward_transform
    px, py = reverse_transform * (x, y)
    px, py = int(px + 0.5), int(py + 0.5)
    pixel_coord = px, py # lon and lat
    return pixel_coord

def lin_func(x, a,m):
	return a + m * x

def bootstrap_ts(initmer,boot):
	initmer.loc[initmer['avgrad'] == 0, 'avgrad'] = initmer.loc[initmer['avgrad'] == 0, 'avgradsl']
	initmer.loc[initmer['avgrad'] == 0, 'cvg'] = initmer.loc[initmer['avgrad'] == 0, 'cvgsl']
	annualavg = np.zeros(8)
	years = ["2012","2013","2014","2015","2016","2017","2018","2019"]
	try:
		out_years = list()
		for xx in years:
			initmery=initmer[initmer.Year==xx]
			nob = initmery.shape[0]
			w = initmery.cvg
			out = np.zeros(boot)
			for yy in range(boot):
				out[yy] = initmery['avgrad'].sample(nob,weights=w, random_state=yy,replace=True).mean()
			out_years.append(out.mean())
		popt, pcov = curve_fit(lin_func,range(2012,2020), out_years, method='lm')
		yhat = lin_func(np.arange(2012,2020,1).astype("float"), *popt)
		out_years = np.array(out_years)
		tss = sum(np.power(out_years - out_years.mean(),2))
		rss = sum(np.power(out_years - yhat,2))
		r2 = 1 - (rss/tss)
		yhat[yhat < 0] = 0
		return(yhat,r2)
	except:
		yhat = np.repeat(0,8)
		r2 = np.repeat(0,1)
		return(yhat,r2)


def bootstrap_ts1(initmer,boot):
	initmer.loc[initmer['avgrad'] == 0, 'avgrad'] = initmer.loc[initmer['avgrad'] == 0, 'avgradsl']
	initmer.loc[initmer['avgrad'] == 0, 'cvg'] = initmer.loc[initmer['avgrad'] == 0, 'cvgsl']
	annualavg = np.zeros(8)
	years = ["2012","2013","2014","2015","2016","2017","2018","2019"]
	try:
		out_years = list()
		for xx in years:
			initmery=initmer[initmer.Year==xx]
			nob = initmery.shape[0] * boot
			w = initmery.cvg
			out = initmery['avgrad'].sample(nob,weights=w, random_state=1,replace=True).mean()
			out_years.append(out)
		popt, pcov = curve_fit(lin_func,range(2012,2020), out_years, method='lm')
		yhat = lin_func(np.arange(2012,2020,1).astype("float"), *popt)
		out_years = np.array(out_years)
		tss = sum(np.power(out_years - out_years.mean(),2))
		rss = sum(np.power(out_years - yhat,2))
		r2 = 1 - (rss/tss)
		yhat[yhat < 0] = 0
		return(yhat,r2)
	except:
		yhat = np.repeat(0,8)
		r2 = np.repeat(0,1)
		return(yhat,r2)

def retrivepixel(lat,lon):


    folder = "/home/fas/seto/pb438/scratch60/VIIRS_Global_vrt"
    allvrts = [y for x in os.walk(folder) for y in glob.glob(os.path.join(x[0], '*.vrt'))]
    files  = [s for s in allvrts if "avgrad_" in s]
    #lat = float(sys.argv[1])
    #lon = float(sys.argv[2])


    # Bright Fire
    #lat = -16.73965673
    #lon = 123.04399244

    presence = list()
    for i in files:
        gdalSrc = gdal.Open(i)
        upx, xres, xskew, upy, yskew, yres = gdalSrc.GetGeoTransform()
        cols = gdalSrc.RasterXSize
        rows = gdalSrc.RasterYSize
        gdalSrc = None
        ulx = upx + 0*xres + 0*xskew
        uly = upy + 0*yskew + 0*yres
        llx = upx + 0*xres + rows*xskew
        lly = upy + 0*yskew + rows*yres
        lrx = upx + cols*xres + rows*xskew
        lry = upy + cols*yskew + rows*yres
        urx = upx + cols*xres + 0*xskew
        ury = upy + cols*yskew + 0*yres
        poly = [(ulx,uly),(urx,ury),(lrx,lry),(llx,lly)]
        check=point_in_poly(lon,lat,poly)
        presence.append(check)

    tilename = files[presence.index(True)].split('/')[-1].split(".")[0].split("_")[1]
    files = getallvrts(folder,tilename)
    imname = getimtypefromvrts(files)

    g = gdal.Open(files[0])
    col,row = retrieve_pixel_value([lon,lat], g)
    g= None

    m1 = openvrt(files[0],row)
    m2 = openvrt(files[1],row)
    m3 = openvrt(files[2],row)
    m4 = openvrt(files[3],row)
    flist1 = get_tif_filenamefrom_vrt(files[0])
    flist2 = get_tif_filenamefrom_vrt(files[1])
    flist3 = get_tif_filenamefrom_vrt(files[2])
    flist4 = get_tif_filenamefrom_vrt(files[3])
    year1,month1 = filenametomonth(flist1)
    year2,month2 = filenametomonth(flist2)
    year3,month3 = filenametomonth(flist3)
    year4,month4 = filenametomonth(flist4)
    years = [year1,year2,year3,year4]
    months = [month1,month2,month3,month4]

    initmer = getpandas(m1,m2,m3,m4,col,years,months,imname)
    initmer.loc[initmer['avgrad'] == 0, 'avgrad'] = initmer.loc[initmer['avgrad'] == 0, 'avgradsl']
    initmer.loc[initmer['avgrad'] == 0, 'cvg'] = initmer.loc[initmer['avgrad'] == 0, 'cvgsl']

    return(initmer)

def outlierremoval(pandasdf):
    x = pandasdf['avgrad']
    x = x.values
    x1 = np.minimum(100*np.log(x + 2),255) # x values greater than ~10.8071 are labelled as 255.
    initstd = np.nanstd(x1)
    # If initial standard deviation is 0 or all values are greater than 11 then no outliers will be detected.
    if initstd == 0:
        newx = x
    else:
        sdlist = list()
        sdlist.append(initstd)
        stdchange = -1
        while stdchange < -0.075:
            x2 = x1
            x2[np.where(x2==np.nanmax(x2))] = np.nan
            newstd = np.nanstd(x2)
            stdchange = (newstd- initstd)
            sdlist.append(newstd)
            initstd = newstd
            if stdchange < -0.075:
                x1 = x2
            
        newx = x1
    if np.sum(np.isnan(newx)) < 50:
        x[np.isnan(newx)] = np.nan
    pandasdf.avgrad = x
    return(pandasdf)

def trendandsingleharmonic(x,m,c,a,a1):
        y = m*x + c + a*np.sin((2*np.pi*x/12)) + a1*np.cos((2*np.pi*x/12))
        return(y)
    
def fittrendandsingleharmonic(pandasdf):
    try:
        pandasdf['x'] = np.arange(pandasdf.shape[0])
        pandasdf = pandasdf.dropna()
        popt, pcov = curve_fit(trendandsingleharmonic,pandasdf.x,pandasdf.avgrad,sigma=1/pandasdf.cvg)
        xx = np.arange(-2,86+8)
        yhat = trendandsingleharmonic(xx.astype("float"), *popt)
        fullyears= np.repeat(range(2012,2020),12)
        outpd= pd.DataFrame(data={'Year':fullyears,'Yhat':yhat})
        out = outpd.groupby('Year')['Yhat'].mean()
        output = out.values
    except:
        output = np.repeat(0,8)
        output = output.astype("float")
    return(output)

def readraster(filename,lineno):
	with rasterio.open(filename) as src:
		rows=src.height
		cols=src.width
		m = src.read(1, window=((lineno-1,lineno), (0, cols)))
	return(m)

